const config = {
        botName: 'ShanBot',
        ownerName: 'Shan',
        youtube: 'YOUTUBE_LINK',
        instagram: 'INSTAGRAM_LINK',
}
