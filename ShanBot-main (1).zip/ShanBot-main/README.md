# BOT EN MANTENIMIENTO

PRONTO CORREGIRE EL ERROR DEL MOTOR
GRACIAS POR LA ESPERA

ShanBot Bot Para Whatsapp by shanduy

<p align="center">
<img src="https://github.com/shanduy/ShanBot/blob/main/temples/ezgif-4-5e4fce2c4bbe.gif" alt="GIF" width="500" height="281"/>
</p>
<p align="center">
<a href="#"><img title="ShanBot" src="https://img.shields.io/badge/ShanBot -purple?colorA=%cc33ff&colorB=%cc33ff&style=for-the-badge"></a>
</p>

<p align="center">
    <img
        src="https://img.shields.io/badge/node.js%20-%2343853D.svg?&style=for-the-badge&logo=node.js&logoColor=white" />
    <img
        src="https://img.shields.io/badge/javascript%20-%23323330.svg?&style=for-the-badge&logo=javascript&logoColor=%23F7DF1E" />
</p>

<p align="center">
<a href="https://github.com/shanduy"><img title="Creador" src="https://img.shields.io/badge/Author-Shanduy-purple.svg?style=for-the-badge&logo=github"></a>
</p>

<p align="center">
  <a href="https://www.youtube.com/channel/UCbNOLyHAy-SL4D9iz9Oi0lw"><img src="https://img.shields.io/badge/YouTube-thepavos-ff0000?style=for-the-badge&logo=youtube&logoColor=ff0000&lihttps://youtu.be/n9fUrhPf5-8-8" /></a>
  <a name=hendra759&label=VIEWS&style=flat-square&color=orange" />

<p align="center">
Mis Redes Sociales Y Mi Whatsapp Para Resolver Tus Problemas
</p>

<p align='center'>
   <a href="https://www.instagram.com/thepavos/"><img height="30" src="https://github.com/shanduy/ShanBot/blob/main/temples/580b57fcd9996e24bc43c521.png?raw=true"></a>&nbsp;&nbsp;
   <a href="https://www.youtube.com/watch?v=2LQSzEbpJ-M"><img height="30" src="https://github.com/shanduy/ShanBot/blob/main/temples/youtube-logo-6-2.png?raw=true"></a>&nbsp;&nbsp;
   <a href="https://wa.me/593967689722"><img height="30" src="https://github.com/shanduy/ShanBot/blob/main/temples/d9d97d48264770f85d35c208f279152c.png?raw=true"></a>
</P>



# ShanBot
ULTIMA VERSION 4.0

Pasos para instalar el bot via termux
https://www.youtube.com/watch?v=2LQSzEbpJ-M


## Como Actualizar Tu Bot 🔄
Para eso vas a cerrar sesión de whatsapp wed en el numero de tu bot y en termux vas a apagar el bot con el comando

```bash
> CTRL y aplastas Z en tu teclado
```

Una vez hecho eso vas a colorcar en termux los siguientes comandos

```bash
> git clone https://github.com/shanduy/ShanBot
> cd ShanBot
> npm start
```

Te dara un nuevo codigo y lo escaneas con tu numero del bot y ya estara la actualizacion de tu bot






## PASOS PARA INSTALAR ShanBot

## Primero Configurar termux
Una vez descargado termux colocas el siguiente comando

```bash
> termux-change-repo
```

## Se te desplegara una venta y harás lo que esta en el video de abajo

![Output sample](https://github.com/shanduy/ShanBot/blob/main/temples/116244521-ad43a780-a770-11eb-88c6-054fb1950bfd%20(1).gif)


## Instalar El Bot
Pasos para instalar el bot en termux

```bash
> pkg install git
> pkg install ffmpeg
> pkg install nodejs
> pkg install wget
> git clone https://github.com/shanduy/ShanBot
> cd ShanBot
> bash install.sh
> npm start
> Y escaneas el QR con tu Whatsapp
```



## ❗Advertencia❗ NUNCA CIERRES LA SESION DE WHATSAPP WEB 🚫




## Soluciones A Errores
Si despues que ya instalastes tu bot y termux te salta en blanco, se fue tu internet o reiniciaste tu celular, solo realizaras estos pasos

```bash
> cd ShanBot
> npm start
```

## Realizas estos pasos como en el video de acontinuacion 

![Output sample](https://github.com/shanduy/ShanBot/blob/main/temples/Screenrecorder-2021-05-12-21-09-23-978.gif)

## Si realizaste este paso y te salio esto

![Settings](https://github.com/shanduy/ShanBot/blob/main/temples/IMG_20210513_155715.jpg)

## Vuelves a poner los comandos

```bash
> cd ShanBot
> npm start
```

## Realizas este paso hasta que te salgo Conectado

![Settings](https://github.com/shanduy/ShanBot/blob/main/temples/IMG_20210513_155631.jpg)


## Prender Y Apagar El Bot

## Para eso nos vamos a dirigir a termux y hacemos lo siguiente 

![Output sample](https://github.com/shanduy/ShanBot/blob/main/temples/Screenrecorder-2021-05-13-16-12-37-825.gif)


## Y para prender el bot solo colocamos

```bash
> npm start
```
![Output sample](https://github.com/shanduy/ShanBot/blob/main/temples/Screenrecorder-2021-05-13-16-12-49-337.gif)



## Y Listo Ya Estara En Funcionamiento. Espero Te Alla Ayudado :)



## by shanduy


