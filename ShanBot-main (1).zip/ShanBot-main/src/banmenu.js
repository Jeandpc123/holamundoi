const banmenu = (prefix, pushname) => {
    return `*Banear El Uso Del Bot*
    
 _El bot necesita de admin_

Este comando impide que el baneado use el bot

══════════════

*PARA BANEAR*

*ban + a la persona que deseas banear

Ejemplo: *ban @xxxxxxx

══════════════

*PARA DESBANEAR*

*desban + a la persona que deseas desbanear

Ejemplo: *desban @xxxxxxx

══════════════

_*by shanduy*_

`

}

exports.banmenu = banmenu
