const version = (prefix, pushname) => {
    return `
*ѕнαηвσт ву ѕнαη∂υу*

*Actualizado:* 18 de Septiembre del 2021
*Versión actual:* 4.0
*Ofrecida por:* shanduy™


*INFORME*

Si no funciona el comando *play o *play2 checa el blog del bot y mira la version que poses 
Ya que ire cambiando mi apikey de mi bot para que siga en funcionamiento
Cambiare la apikey pasando un mes o si veo muchos atercados o robos
Si vez a alguien que robo mi bot comunicate conmigo con el comando *creador


*COMO ACTUALIZAR EL BOT*

https://cutt.ly/dWp5uqE


*SIGUEME EN INSTAGRAM 🥸🧉*

https://www.instagram.com/thepavos


_*by shanduy*_
`

}

exports.version = version
