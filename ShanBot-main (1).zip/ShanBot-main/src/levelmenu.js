const levelmenu = (prefix, pushname) => {
    return `

*Comandos De Level 🆕 beta*
 
══════════════

PARA ACTIVARLO EL BOT NECESITA DE ADMINISTRACIÓN

*PARA ACTIVAR LEVEL*

*leveling 1


*PARA DESACTIVAR LEVEL*

*leveling 0

══════════════

PARA VER TU XP EN TIEMPO REAL

*level

══════════════
    
*Recuerda que si actualizas tu bot o borras el numero del bot o otra cosa todos los levels de los particiantes quedaran en 0*
    
_*by shanduy*_
`

}

exports.levelmenu = levelmenu
