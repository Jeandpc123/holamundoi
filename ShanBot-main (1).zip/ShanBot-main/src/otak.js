const otak = (prefix, pushname) => {
    return `*Palabras especificas para que el bot interactue con ustedes mis queridos otakus*


Quien es tu sempai botsito
Me gimes 7u7
Te amo botsito uwu
Onichan
La toca 7w7


_*Ojito escribe tal como esta*_

ву ѕнαη∂υу`

}

exports.otak = otak
