const shantera = (prefix, pushname) => {
    return `*Palabras especificas para que el bot interactue con ustedes*


Hora del sexito
Pongan cuties
Fiesta del admin
Admin party
Viernes
GOOOOD
Alto temazo
Todo bien
Buenos dias
Bot gay
Gracias
Hola
Fua
Corte
Gaspi buenos dias 
Gaspi me saludas
Gaspi y las minitas
Gaspi todo bien
Me quiero suicidar
Gaspi ya no aguanto
Contate algo bot
Sexo
Momento epico
El bot del orto no funciona
Epicardo
Insta de la minita
Una mierda de bot
Ultimo momento
Nefasto
Paraguayo
Bot de mierda
Venezolano
Gaspi corte
Ya me voy a dormir
Calefon
Apurate bot
Un chino
No funciona
Boliviano
Enano


_*Ojito escribe tal y como esta en el mensaje*_

ву ѕнαη∂υу`

}

exports.shantera = shantera
